$(document).ready(function () {
    var socket = io(); //1

    $('#form1').submit(function(){
        var data = $("#form1").serializeArray();
        socket.emit('posing_form', {data: data})
        return false;
    })
    socket.on('data', function(data){
        console.log(data);
        var rand = Math.floor(Math.random() * 1000) + 1;
        sentence = data.data + " Your lucky number is: " + rand;
        document.getElementById("infoDiv").innerHTML = sentence;
    })
});