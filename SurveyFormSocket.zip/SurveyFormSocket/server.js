const express = require("express");
var path = require("path");
const app = express();
const server = app.listen(8000);
const io = require('socket.io')(server);
var bodyParser = require('body-parser');
var session = require('express-session');
const axios = require("axios");
var counter = 0;
app.use(bodyParser.urlencoded({ extended: false }));
app.use(express.static(path.join(__dirname, "./static")));
app.set('views', path.join(__dirname, './views'));
app.set('view engine', 'ejs');
app.use(session({
    secret: 'superSercretCode!',
    resave: false,
    saveUninitialized: true,
    cookie: { maxAge: 60000 }
}));

app.get('/', function (req, res) {
    res.render("index");
});

io.on('connect', function(socket){
    socket.on('posing_form', function(data){
        console.log(data.data[1].value);
        var name = data.data[0].value;
        var loc = data.data[1].value;
        var lan = data.data[2].value;
        var com = data.data[3].value;
        var sentence = "You emmited the following information to the server: {name: " + name + ", location: " + loc + ", language: " + lan + ", comment: " + com + "}";
        console.log(sentence);
        socket.emit('data', {data: sentence});
    })
});

