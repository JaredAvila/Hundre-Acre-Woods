var express = require('express');
var app = express();
var mongoose = require('mongoose');
var uniqueValidator = require('mongoose-unique-validator');
var bodyParser = require('body-parser');
app.use(bodyParser.urlencoded({ extended: true }));
var path = require('path');
const bcrypt = require('bcrypt');
const flash = require('express-flash');
var session = require('express-session');
app.set('trust proxy', 1);
app.use(session({
    secret: 'superSercretCode!',
    resave: false,
    saveUninitialized: true,
    cookie: { maxAge: 60000 }
}));
app.use(flash());
app.use(express.static(path.join(__dirname, './static')));
app.set('views', path.join(__dirname, './views'));
app.set('view engine', 'ejs');
//----------------------------------------------------------------------- Routes
//-------------------------------------------------------------------- Root Request

app.get('/', function (req, res) {
    res.render("index");
})

app.post('/login', function (req, res) {
    User.findOne({ email: req.body.email }, function (err, user) {
        console.log("errors? " + err + " email: " + req.body.email);
        if (err) {
            console.log("Found errors: " + err);

            for (var key in err.errors) {
                req.flash('login', err.errors[key].message);
            }
            res.redirect('/');
        }
        else {
            if (user) {
                console.log("we have a user: " + user);
                req.session.user_id = user._id;
                req.session.email = user.email;
                res.redirect("/home");
            } else {
                console.log("We dont have a user: " + user);
                req.flash('login', "Invalid data. Try again");
                res.redirect("/");
            }

        }
    });
});

app.post('/register', function (req, res) {
    if (req.body.password !== req.body.passwordConf) {
        req.flash('registration', "Passwords do not match");
        res.redirect('/');
    }
    var today = new Date();
    var dd = today.getDate();
    var mm = today.getMonth() + 1;
    var yyyy = today.getFullYear();
    if (dd < 10) {
        dd = '0' + dd
    }
    if (mm < 10) {
        mm = '0' + mm
    }
    yyyy -= 12;
    today = yyyy + '-' + mm + '-' + dd;
    if (req.body.birthday > today) {
        req.flash('registration', "Must be older than 13 to join.")
        res.redirect('/');
    } else {
        var user = new User(req.body);
        user.save(function (err) {
            if (err) {
                for (var key in err.errors) {
                    req.flash('registration', err.errors[key].message);
                }
                res.redirect('/');
            } else {
                console.log("Success! You have created a new user.");
                req.session.user_id = user._id;
                req.session.email = user.email;
                res.redirect('/home');
            }
        });
    }

})

app.get('/home', function (req, res) {
    console.log(req.session.user_id);
    User.findById(req.session.user_id, function(err, user){
        if(err){
            res.redirect('/');
        } else {
            res.render('home', {user: user});
        }
    })
})

//-------------------------------------------------------------------connections - n - stuffs

app.listen(8000, function () {
    console.log("listening on port 8000");
})

mongoose.connect('mongodb://localhost/login', {
    useCreateIndex: true,
    useNewUrlParser: true
});
const UserSchema = new mongoose.Schema({
    firstName: { type: String, required: [true, "First name can't be left blank"], minlength: [3, "Name must be longer than 3 characters"] },
    lastName: { type: String, required: [true, "Last name can't be left blank"], minlength: [3, "Name must be longer than 3 characters"] },
    email: { type: String, required: [true, "Email can't be left blank"], unique: [true, "Email already belongs to an account."], match: [/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/, 'Please use a valid email address'] },
    password: { type: String, required: [true, "Password can't be left blank"], minlength: [6, "Password must be longer than 6 characters"] },
    birthday: { type: Date, required: [true, "Please select a valid birthday"] }
}, { timestamps: true });
UserSchema.plugin(uniqueValidator);
mongoose.model('User', UserSchema);
mongoose.Promise = global.Promise;
var User = mongoose.model('User');