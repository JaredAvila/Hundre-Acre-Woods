const express = require("express");
var path = require("path");
const app = express();
var bodyParser = require('body-parser');
const server = app.listen(8000);
const io = require('socket.io')(server);
var color = "";
//-----------REAL TIME COLORS------------------------------------
app.set('views', path.join(__dirname, './views'));
app.set('view engine', 'ejs');
app.use(bodyParser.urlencoded({ extended: false }));
app.use(express.static(path.join(__dirname, "./static")));
// -----------ROUTES---------------------------------------------
app.get('/home', function (req, res) {
    var color = "";
    res.render('home', {color: color});
});
//-----------SOCKET----------------------------------------------
io.on('connect', function(socket){
    io.emit('updateColor', {color: color});
    socket.on('newColor', function(data){
        io.emit('updateColor', {color: data.color});
    });
});
