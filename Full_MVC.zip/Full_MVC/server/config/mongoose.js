var mongoose = require('mongoose');
module.exports = mongoose.connect('mongodb://localhost/quoting_dojo', { useNewUrlParser: true });