var express = require('express');
var app = express();
var mongoose = require('mongoose');
var bodyParser = require('body-parser');
app.use(bodyParser.urlencoded({ extended: true }));
var path = require('path');
const flash = require('express-flash');
var session = require('express-session');
app.use(session({
    secret: 'superSercretCode!',
    resave: false,
    saveUninitialized: true,
    cookie: { maxAge: 60000 }
}));
app.use(flash());
app.use(express.static(path.join(__dirname, './static')));
app.set('views', path.join(__dirname, './views'));
app.set('view engine', 'ejs');
//----------------------------------------------------------------------- Routes
//-------------------------------------------------------------------- Root Request
app.get('/home', function (req, res) {
    res.render('home');
})

app.post('/home', function (req, res) {
    // console.log(req.body.name + req.body.quote);
    var quote = new Quote(req.body);
    quote.save(function (err) {
        if (err) {
            for (var key in err.errors) {
                req.flash('registration', err.errors[key].message);
            }

            res.redirect('/home');
        } else {
            res.redirect('/quotes');
        }
    });
})

app.get('/quotes', function (req, res) {
    Quote.find({}, function (err, quotes) {
        if (err) {
            res.redirect('/');
        } else {
            
            res.render('quotes', { quotes: quotes });
        }
    }).sort( { createdAt: -1 } );
})


app.listen(8000, function () {
    console.log("listening on port 8000");
})

mongoose.connect('mongodb://localhost/quoting_dojo', { useNewUrlParser: true });
var QuoteSchema = new mongoose.Schema({
    name: { type: String, required: true, minlength: 5 },
    quote: { type: String, required: true, minlength: 10 }
}, { timestamps: true });
mongoose.model('Quote', QuoteSchema);
mongoose.Promise = global.Promise;
var Quote = mongoose.model('Quote');