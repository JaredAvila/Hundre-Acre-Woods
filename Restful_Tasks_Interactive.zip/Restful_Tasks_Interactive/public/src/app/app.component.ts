import { Component, OnInit } from '@angular/core';
import { HttpService } from './http.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  constructor(private _httpService: HttpService) { };
  ngOnInit() {
  }
  info: {};
  tasks = [];
  getTasksFromService() {
    let obsr = this._httpService.getTasks();
    obsr.subscribe(data => {
      console.log("Got our tasks again! This time from contollers! ", data)
      this.tasks = data['tasks'];
    });
  }
  getTaskById(id: string){
    console.log(`Click works like a charm! ${id}`)
    let obsr = this._httpService.getById(id);
    obsr.subscribe(data=> {
      console.log("It fucking worked! HOLY SHIT!", data['task']);
      this.info = data['task'];
    })
  }
  onButtonClick(): void {
    console.log(`Click event is working`);
  }
  onButtonClickParam(num: Number): void {
    console.log(`Click event is working with num param: ${num}`);
    let observ = this._httpService.postToServer({data:num});
    observ.subscribe(data=> console.log("Got yer data right here! ", data));
  }
  onButtonClickParams(num: Number, str: String): void {
    console.log(`Click event is working with num param: ${num} and str param: ${str}`);
  }
  onButtonClickEvent(event: any): void {
    console.log(`Click event is working with event: ${event}`);
  }
}
