const mongoose = require('mongoose'),
    Task = mongoose.model('Task')
var tasks = require('../controllers/tasks.js');
module.exports = function(app) {
    app.get('/', function(req, res) {
        res.render('index');
    })
    app.get('/tasks', function(req, res) {
        tasks.getAll(req, res);
    })
    app.get('/task/:id', function(req, res) {
        tasks.findTask(req, res);
    })
    app.post('/task/:title', function(req, res) {
        tasks.creation(req, res);
    })
    app.put('/task/:id/:title/:desc', function(req, res) {
        tasks.update(req, res);
    })
    app.delete('/task/:id', function(req,res) {
        tasks.destroy(req, res);
    })
}