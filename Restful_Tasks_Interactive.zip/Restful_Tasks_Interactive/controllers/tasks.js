const mongoose = require('mongoose');
Task = mongoose.model('Task');
module.exports = {
    getAll: function(req, res) {
        Task.find({}, function(err, tasks){
            if(err){
                res.json({error:err});
            } else {
                res.json({tasks : tasks});
            }
        })
    },
    findTask: function(req, res){
        Task.findById({_id : req.params.id}, function(err, task) {
            if(err){
                res.json({error: err});
            } else {
                res.json({task:task});
            }
        })
    },
    creation: function(req, res) {
        var task = new Task({title:req.params.title});
        task.save(function(err) {
            if(err) {
                res.json({error: err});
            } else {
                res.json({task:task});
            }
        })
    },
    update: function(req, res) {
        Task.findOneAndUpdate({_id:req.params.id}, { title: req.params.title, description: req.params.desc }, function(err){
            if(err){
                res.json({error: err});
            } else{
                res.redirect('/tasks');
            }
        })
    },
    destroy: function(req, res){
        Task.findByIdAndDelete({_id : req.params.id}, function(err){
            if (err){
                res.json({error:err})
            } else{
                res.redirect("/tasks")
            }
        })
    }
}