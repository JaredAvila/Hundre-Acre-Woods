var mongoose = require('mongoose');
require('../config/mongoose.js');
module.exports = {
    cake: function () {
        var CommentSchema = new mongoose.Schema({
            comment: {type:String, required:[true, "Comment can't be left blank"]},
            rating: {type:String, required:[true, "Must leave a rating"]}
        })
        var CakeSchema = new mongoose.Schema({
            name: { type: String, required: [true, "Must enter a name"] },
            imgUrl: { type: String, required: [true, "Must include a picture url"] },
            comments: [CommentSchema]
        }, { timestamps: true });
        mongoose.model('Cake', CakeSchema);
        mongoose.model('Comment', CommentSchema);
        return mongoose.model('Cake'), mongoose.model('Comment');
    }
}