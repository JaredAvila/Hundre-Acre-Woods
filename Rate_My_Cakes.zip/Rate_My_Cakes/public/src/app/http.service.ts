import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class HttpService {

  constructor(private _http: HttpClient) { }

  getCakes() {
    return this._http.get('/cakes');
  }
  getCake(id: string){
    console.log("arrived in getCake with: ", id);
    return this._http.get(`/cake/${id}`);
  }
  createCake(newCake){
    return this._http.post('/cake/new', newCake);
  }
  createComment(newComment){
    console.log("Arrived in createComment with new comment to post: ", newComment);
    return this._http.post('/comment', newComment);
  }
  updateComments(cake, comment){
    console.log("Arrived in updateComments with new comment to post: ", cake, comment);
    return this._http.post('/cakes/comment', {cake:cake, comment:comment});
  }
}
