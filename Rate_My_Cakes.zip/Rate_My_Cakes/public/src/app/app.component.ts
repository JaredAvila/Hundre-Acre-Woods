import { Component, OnInit } from '@angular/core';
import { HttpService } from './http.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  constructor(private _httpService: HttpService){};
  allCakes = [];
  newCake= {name: "", imgUrl:""};
  newComment={comment:"", rating:""};
  cakeId = '';
  selectedCake:any;
  ngOnInit(){
    this.getAllCakes();
  };
  getAllCakes(){
    let obs = this._httpService.getCakes();
    obs.subscribe(data => {
      this.allCakes = data["success"];
    })
  }
  postComment(cakeId : string){
    console.log("Arrived in postComment", cakeId);
    let obs = this._httpService.createComment(this.newComment);
    obs.subscribe(data => {
      console.log("back in postComment with new comment: ", data)
      this.commentCake(data, cakeId);
    })
  }
  postCake(){
    let obs = this._httpService.createCake(this.newCake);
    obs.subscribe(data => {console.log("Made a new cake!", data)
    this.getAllCakes();
    this.newCake= {name: "", imgUrl:""};
  })
  }
  commentCake(comment, cakeID){
    console.log("arrived in commentCake with comment: ", comment, " and cakeID: ", cakeID);
    let cakeObs = this._httpService.getCake(cakeID);
    cakeObs.subscribe(cake => {
      console.log("back in commentCake with new cake to be commented: ", cake)
      let newCom = this._httpService.updateComments(cake, comment);
      newCom.subscribe(newCake => {
        console.log("back in commentCake withe newly commented cake: ", newCake);
        this.cakeId = "";
        this.newComment = {comment:"", rating:""};
        this.getAllCakes();
      })
    })
  }
  cakeToShow(cake){
    this.selectedCake = cake;
  }
  modalShow(){
    document.getElementById("ui-Overlay").style.display = "block";
    document.getElementById("cakeApp").style.display = "block";
  }
  modalHide(){
    document.getElementById("ui-Overlay").style.display = "none";
    document.getElementById("cakeApp").style.display = "none";
  }
}
