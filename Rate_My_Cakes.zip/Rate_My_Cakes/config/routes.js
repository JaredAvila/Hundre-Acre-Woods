const mongoose = require('mongoose'),
    Cake = mongoose.model('Cake')
var cakes = require('../controllers/cakes.js');
module.exports = function(app) {
    app.get('/cakes',function(req, res){
        cakes.getAll(req,res);
    });

    app.get('/cake/:id', function(req, res){
        console.log("arrived at the /cake/:id get route with: ", req.body)
        cakes.getCakeById(req, res);
    })

    app.post('/cake/new', function(req, res){
        cakes.newCake(req, res);
    });

    app.post('/cakes/comment', function(req, res){
        cakes.updateComments(req, res);
    })

    app.put('/cakes/:id/:name/', function(req, res){
        cakes.editCake(req, res);
    })
    
    app.delete('/cakes/:id', function(req, res){
        cakes.deleteCake(req, res);
    })

    app.post('/comment', function(req, res){
        console.log("arrived at the /comment post route with: ", req.body);
        cakes.newComment(req, res);
    })
}