var mongoose = require('mongoose');
module.exports = mongoose.connect('mongodb://localhost/Rate_My_Cakes', { useNewUrlParser: true });
