const mongoose = require('mongoose');
Cake = mongoose.model('Cake');
Comment = mongoose.model('Comment');
module.exports = {
    newCake(req, res) {
        var cake = new Cake({ name: req.body.name, imgUrl: req.body.imgUrl });
        cake.save(function (err) {
            if (err) {
                res.json({ error: err });
            } else {
                res.json({ success: cake });
            }
        })
    },
    getAll(req, res) {
        Cake.find({}, function (err, data) {
            if (err) {
                res.json({ 'error': 'something went wrong.' });
            } else {
                res.json({ success: data });
            }
        })
    },
    getCakeById(req, res) {
        console.log("arrived in getCakeById with: ", req.body);
        Cake.findById(req.params.id, function (err, cake) {
            if (err) {
                res.json({ error: err });
            } else {
                res.json({ success: cake });
            }
        })
    },
    editCake(req, res) {
        Cake.findOneAndUpdate({ _id: req.params.id }, { name: req.params.name }, function (err, cake) {
            if (err) {
                res.json({ error: err })
            } else {
                res.json({ success: cake });
            }
        })
    },
    commentCake(cake, comments){
        console.log('arrived in commentCake with: ', cake, " and ", comments);
        Cake.findOneAndUpdate({ _id: cake._id }, { comments: comments }, function(err, cake){
            if(err){
                return err;
            } else{
                console.log("updated the cake! ", cake);
                return cake;
            }
        })
    },
    deleteCake(req, res) {
        Cake.findOneAndDelete({ _id: req.params.id }, function (err, cake) {
            if (err) {
                res.json({ error: err });
            } else {
                res.json({ deleted: cake });
            }
        })
    },
    newComment(req, res) {
        console.log("arrived in newComment with: ", req.body);
        var comment = new Comment({
            comment: req.body.comment,
            rating: req.body.rating
        });
        comment.save(function (err) {
            if (err) {
                res.json({ error: err });
            } else {
                console.log("successfully saved new comment");
                res.json({ success: comment });
            }
        })
    },
    updateComments(req, res) {
        console.log("arrived in updateComments with: ", req.body);
        if (req.body.cake['error'] || req.body.comment['error']) {
            res.json({ error: "Something went wrong. Sorry" });
        } else {
            let comments = req.body.cake['success'].comments;
            comments.push(req.body.comment['success']);
            let cake = this.commentCake(req.body.cake['success'], comments);
            res.json({success: cake});
        }

    }
}