var express = require('express');
var app = express();
var mongoose = require('mongoose');
var bodyParser = require('body-parser');
app.use(bodyParser.json());
mongoose.connect('mongodb://localhost/api_1955', { useNewUrlParser: true });
const UserSchema = new mongoose.Schema({
    name: { type: String, required: [true, "Name can't be left blank"] }
}, { timestamps: true });
mongoose.Promise = global.Promise;
mongoose.model('User', UserSchema);
var User = mongoose.model('User');
app.get('/', function(req, res){
    User.find({}, function(err, users){
        if(err){
            var data = {errors: err};
            res.json(data);
        } else{
            res.json(users);
        }
    })
})
app.get('/new/:name', function(req, res){
    var user = new User({name:req.params.name});
    user.save(function(err){
        if(err){
            res.json({data : err});
        } else {
            res.json({newUser : user});
        }
    })
});
app.get('/remove/:name', function(req, res){
    User.findOneAndDelete({name: req.params.name}, function(err){
        if(err){
            res.json({errors:err});
        } else{
            res.redirect('/');
        }
    })
})
app.get('/:name', function(req, res){
    User.findOne({name:req.params.name}, function(err, user){
        if(err){
            res.json({errors: err});
        }else{
            res.json({user:user});
        }
    })
})


app.listen(8000, function () {})