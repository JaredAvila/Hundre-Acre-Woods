var mongoose = require('mongoose');
require('../config/mongoose.js');
module.exports = {
    author: function() {
        var AuthorSchema = new mongoose.Schema({
            name: { type: String, minlength: 3 }
        }, { timestamps: true });
        mongoose.model('Author', AuthorSchema);
        mongoose.model('Author');
    }
}