const mongoose = require('mongoose');
Author = mongoose.model('Author');
module.exports = {
    getAll: function (req, res) {
        Author.find({}, function (err, authors) {
            if (err) {
                res.json({ error: err });
            } else {
                res.json({ author: authors });
            }
        })
    },
    findAuthor: function (req, res) {
        Author.findById({ _id: req.params.id }, function (err, author) {
            if (err) {
                res.json({ error: err });
            } else {
                res.json({ author: author });
            }
        })
    },
    createAuthor: function (req, res) {
        var author = new Author({ name: req.body.name });
        console.log("We are in authors.js. Here is the data: " + req.body)
        author.save(function (err) {
            if (err) {
                res.json({ error: err });
            } else {
                res.json({ author: author });
            }
        })
    },
    updateAuthor: function (req, res) {
        if (req.body.name === "" || req.body.name.length < 3) {
            res.json({ error: "Name must be longer than 3 characters" });
        } else {
            Author.findOneAndUpdate({ _id: req.body.id }, { name: req.body.name }, function (err) {
                if (err) {
                    res.json({ error: err });
                } else {
                    res.json({ updated: req.body.name });
                }
            })
        }

    },
    destroyAuthor: function (req, res) {
        Author.findByIdAndDelete({ _id: req.params.id }, function (err) {
            if (err) {
                res.json({ error: err })
            } else {
                res.json({ sucess: 'IT WORKS!!! YAY' });
            }
        })
    }
}