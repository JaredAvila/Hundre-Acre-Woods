import { Component, OnInit } from '@angular/core';
import { HttpService } from '../http.service';
import { ActivatedRoute } from '@angular/router';
import { Router } from "@angular/router"

@Component({
  selector: 'app-view-authors',
  templateUrl: './view-authors.component.html',
  styleUrls: ['./view-authors.component.css']
})
export class ViewAuthorsComponent implements OnInit {

  constructor(private _httpService: HttpService, private _route: ActivatedRoute, private router: Router) { }
  authorToEdit = { id: "", name: "" };
  authorId: any;
  errorMsg = "";
  ngOnInit() {
    this._route.params.subscribe(params => {
      this.authorId = params;
      let obs = this._httpService.getAuthor(params["id"]);
      obs.subscribe(data => {
        this.authorToEdit.name = data['author'].name;
        this.authorToEdit.id = data['author']._id;
      })
    })
  }

  editAuthor() {
    console.log(this.authorToEdit);
    let obs = this._httpService.editAuthor(this.authorToEdit);
    obs.subscribe(data => {
      console.log("What did we get?", data);
      if (data['error']) {
        this.errorMsg = data['error'];
      } else {
        this.authorToEdit = { id: "", name: "" };
        this.router.navigate(['/home']);
      }
    })

  }

}
