import { AddAuthorComponent } from './add-author/add-author.component';
import { HomeComponent } from './home/home.component';
import { ViewAuthorsComponent } from './view-authors/view-authors.component';
import { PagenotfoundComponent } from './pagenotfound/pagenotfound.component';
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

const routes: Routes = [
  { path: 'addAuthor', component: AddAuthorComponent },
  { path: 'viewAuthor/:id', component: ViewAuthorsComponent },
  { path: 'home', component: HomeComponent },
  { path: '', pathMatch: 'full', redirectTo: '/home' },
  { path: '**', component: PagenotfoundComponent }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
