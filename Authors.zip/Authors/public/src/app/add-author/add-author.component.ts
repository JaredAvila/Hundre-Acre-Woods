import { Component, OnInit } from '@angular/core';
import { HttpService } from '../http.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-add-author',
  templateUrl: './add-author.component.html',
  styleUrls: ['./add-author.component.css']
})
export class AddAuthorComponent implements OnInit {

  constructor(private _httpService: HttpService, private _router: Router) { }
  name = "";
  errorMsg = "";
  ngOnInit() {
  }
  newAuthor() {
    console.log("in new author, name is: ", this.name);
    let obs = this._httpService.newAuthor(this.name);
    obs.subscribe(data => {
      console.log("this is the data recieved: ", data);
      if (data['error']) {
        this.errorMsg = "Name must be at least 3 characters";
      } else {
        this.name = "";
        this._router.navigate(['/home']);
      }
    })

  }
}
