import { Component, OnInit } from '@angular/core';
import { HttpService } from '../http.service';
import {Router} from "@angular/router"

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  constructor(private _httpService: HttpService, private router: Router) { }
  authors = [];
  id = "";
  ngOnInit() {
    this.getAllAuthors();
  }
  getAllAuthors(){
    let obs = this._httpService.getAll();
    obs.subscribe(data => {
      this.authors = data['author'];
      console.log("Here's the data from '/authors': ", data)
    })
  }
  deleteAuthor(id){
    console.log("this is the id: ", id);
    let obs = this._httpService.deleteAuthor(id);
    obs.subscribe(data => {
      console.log("should be deleted now. ", data);
    })
    this.getAllAuthors();
  }
}
