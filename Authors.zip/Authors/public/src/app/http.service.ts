import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class HttpService {

  constructor(private _http: HttpClient) { }
  getAll(){
    return this._http.get('/authors');
  }
  newAuthor(name){
    return this._http.post('/author/new', {name: name});
  }
  authorToEdit: any;
  getAuthor(id){
    let url = "/author/" + id;
    return this._http.get(url);
  }
  editAuthor(author){
    console.log("In SERVICE: ", author.id);
    let url = '/author/' + author.id + '/edit';
    return this._http.put(url, author);
  }
  deleteAuthor(id){
    let url = '/author/delete/' + id;
    console.log("in service: ", url);
    return this._http.delete(url);
  }
}
