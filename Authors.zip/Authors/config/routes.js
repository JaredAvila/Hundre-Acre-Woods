const mongoose = require('mongoose'),
    Author = mongoose.model('Author')
var authors = require('../controllers/authors.js');
module.exports = function(app) {
    app.get('/authors', function(req, res) {
        authors.getAll(req, res);
    })
    app.get('/author/:id', function(req, res) {
        console.log("Express reviced the author data: ", req.params.id)
        authors.findAuthor(req, res);
    })
    app.post('/author/new', function(req, res) {
        console.log("Data has arrived in Routes. We are now in Express! ", req.body)
        authors.createAuthor(req, res);
    })
    app.put('/author/:id/edit', function(req, res) {
        console.log("data has arrived in Express: ", req.body)
        authors.updateAuthor(req, res);
    })
    app.delete('/author/delete/:id', function(req,res) {
        console.log("arrived in routes.js.")
        authors.destroyAuthor(req, res);
    })
    app.all("*", (req,res,next) => {
        res.sendFile(path.resolve("./public/dist/public/index.html"))
      });
}