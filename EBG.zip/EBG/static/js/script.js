$(document).ready(function(){
    var socket = io();
    $("#epic").on('click', function(){
        var butId = "epic";
        var num = document.getElementById("count").innerHTML;
        console.log(num);
        socket.emit('clicked', {number: num});
    })
    $("#reset").on('click', function(){
        if(document.getElementById("count").innerHTML){
            var num = document.getElementById("count").innerHTML;
            socket.emit('clear', {number: num});
        }
        
    })
    socket.on('clicks', function(data){
        document.getElementById("count").innerHTML = data.data;
        console.log("Recieved: " + data.data);
    })



});