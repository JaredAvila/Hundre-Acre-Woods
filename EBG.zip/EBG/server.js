const express = require("express");
var path = require("path");
const app = express();
var bodyParser = require('body-parser');
var session = require('express-session');
const server = app.listen(8000);
const io = require('socket.io')(server);
app.set('views', path.join(__dirname, './views'));
app.set('view engine', 'ejs');
app.use(bodyParser.urlencoded({ extended: false }));
app.use(express.static(path.join(__dirname, "./static")));
app.use(session({
    secret: 'superSercretCode!',
    resave: false,
    saveUninitialized: true,
    cookie: { maxAge: 60000 }
}));
app.get('/home', function (req, res) {
    if(req.session.counter=== undefined){
        req.session.counter = 0;
    }
    io.emit('updateClicks', {count: req.session.counter});
    res.render("home", {count: req.session.counter});
});
io.on('connect', function(socket){
    socket.on('clicked', function(data){
        data.number = parseInt(data.number) + 1;
        io.emit('clicks', {data: data.number} )
    })
    socket.on('clear', function(data){
        console.log(data.number);
        data.number = 0;
        io.emit('clicks', {data: data.number});
    })
});
