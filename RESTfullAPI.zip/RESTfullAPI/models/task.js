var mongoose = require('mongoose');
require('../config/mongoose.js');
module.exports = {
    task: function () {
        var TaskSchema = new mongoose.Schema({
            title: { type: String },
            description: { type: String },
            completed: { type: Boolean }
        }, { timestamps: true });
        mongoose.model('Task', TaskSchema);
        return mongoose.model('Task');
    }
}