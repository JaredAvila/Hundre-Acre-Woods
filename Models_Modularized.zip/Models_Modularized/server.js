var express = require('express');
var app = express();
var mongoose = require('mongoose');
var bodyParser = require('body-parser');
app.use(bodyParser.urlencoded({ extended: true }));
var path = require('path');
const flash = require('express-flash');
var session = require('express-session');
app.use(session({
    secret: 'superSercretCode!',
    resave: false,
    saveUninitialized: true,
    cookie: { maxAge: 60000 }
}));
app.use(flash());
app.use(express.static(path.join(__dirname, './static')));
app.set('views', path.join(__dirname, './views'));
app.set('view engine', 'ejs');
app.listen(8000, function () {})
//need to set model b4 getting it!!!
mongoose.Promise = global.Promise;
var quote = require('./server/models/quote.js');
quote.quote();
require('./server/config/routes.js')(app)