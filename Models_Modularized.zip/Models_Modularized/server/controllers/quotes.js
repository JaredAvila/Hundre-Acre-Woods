const mongoose = require('mongoose'),
    Quote = mongoose.model('Quote')
module.exports = {
    home: function (req, res) {
        var quote = new Quote(req.body);
        quote.save(function (err) {
            if (err) {
                for (var key in err.errors) {
                    req.flash('registration', err.errors[key].message);
                }

                res.redirect('/home');
            } else {
                res.redirect('/quotes');
            }
        });
    },
    create: function (req, res) {
        Quote.find({}, function (err, quotes) {
            if (err) {
                res.redirect('/');
            } else {

                res.render('quotes', { quotes: quotes });
            }
        }).sort({ createdAt: -1 });
    }
};


