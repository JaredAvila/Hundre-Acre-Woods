var mongoose = require('mongoose');
mongoose.connect('mongodb://localhost/quoting_dojo', { useNewUrlParser: true });
module.exports = {
    quote: function(){
    var QuoteSchema = new mongoose.Schema({
        name: { type: String, required: true, minlength: 5 },
        quote: { type: String, required: true, minlength: 10 }
    }, { timestamps: true });
    mongoose.model('Quote', QuoteSchema);
    return mongoose.model('Quote');
}

}
