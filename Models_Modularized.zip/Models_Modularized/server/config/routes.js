const mongoose = require('mongoose')
    // Quote = mongoose.model('Quote')
var quotes = require('../controllers/quotes.js');
module.exports = function (app) {
    app.get('/home', function (req, res) {
        res.render('home');
    })
    app.post('/home', function (req, res) {
        quotes.home(req, res);
    })

    app.get('/quotes', function (req, res) {
        quotes.create(req, res);
    })
}