$(document).ready(function () {
    $("#people").on('click', function () {
        var next = "";
        var prev = "";
        $.get('/people', function (data) {
            var html = "";
            for (var i = 0; i < data.results.length; i++) {
                html += "<p>" + data.results[i].name + "</p>"
            }
            document.getElementById("showcase").innerHTML = html;
            $("#next").on('click', function(){
                $.get('/people', function (data) {
                    for (var i = 0; i < data.results.length; i++) {
                        html += "<p>" + data.results[i].name + "</p>"
                    }
                    document.getElementById("showcase").innerHTML = html;
                }, 'json');
                console.log("hello");
            });
            $('#showcase').on('scroll', function() {
                if($(this).scrollTop() + $(this).innerHeight() >= $(this)[0].scrollHeight) {
                    $.get('/people', function (data) {
                        for (var i = 0; i < data.results.length; i++) {
                            html += "<p>" + data.results[i].name + "</p>"
                        }
                        document.getElementById("showcase").innerHTML = html;
                    }, 'json');
                }
            })
        }, 'json');
    });
    $("#planets").on('click', function () {
        $.get('/planets', function (data) {
            var html = "";
            for (var i = 0; i < data.results.length; i++) {
                html += "<p>" + data.results[i].name + "</p>"
            }
            document.getElementById("showcase").innerHTML = html;
        }, 'json');
    });
});