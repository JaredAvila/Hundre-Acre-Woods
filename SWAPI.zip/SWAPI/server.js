var express = require("express");
var path = require("path");
var app = express();
var bodyParser = require('body-parser');
var session = require('express-session');
const axios = require("axios");


app.use(session({
    secret: 'superSercretCode!',
    resave: false,
    saveUninitialized: true,
    cookie: { maxAge: 60000 }
}))
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, "./static")));
app.set('views', path.join(__dirname, './views'));
app.set('view engine', 'ejs');


app.get('/', function (req, res) {
    req.session.nextPlanets = "https://swapi.co/api/planets/";
    req.session.nextPeople = "https://swapi.co/api/people/";
    res.render("people");
})
app.get('/people', function (req, res) {
    axios.get(req.session.nextPeople)
    .then(data => {
        req.session.nextPeople = data.data.next;
        res.json(data.data);
    })
    .catch(error => {
        console.log(error);
        res.json(error);
    })
})
app.get('/planets', function (req, res) {
    axios.get("https://swapi.co/api/planets/")
    .then(data => {
        console.log(data);
        res.json(data.data);
    })
    .catch(error => {
        console.log(error);
        res.json(error);
    })
})


app.listen(8000, function () {
    console.log("listening on port 8000");
});