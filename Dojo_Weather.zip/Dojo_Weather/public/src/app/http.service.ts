import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class HttpService {

  constructor(private _http: HttpClient) { 
  }
  getSanjose(){
    return this._http.get('http://api.openweathermap.org/data/2.5/weather?q=cupertino&APPID=3a7e4c95c0333ec8406259e91cb89bc4')
  }
  getBurbank(){
    return this._http.get('http://api.openweathermap.org/data/2.5/weather?q=burbank&APPID=3a7e4c95c0333ec8406259e91cb89bc4')
  }
  getSeattle(){
    return this._http.get('http://api.openweathermap.org/data/2.5/weather?q=seattle&APPID=3a7e4c95c0333ec8406259e91cb89bc4')
  }
  getDc(){
    return this._http.get('http://api.openweathermap.org/data/2.5/weather?q=washington&APPID=3a7e4c95c0333ec8406259e91cb89bc4')
  }
  getDallas(){
    return this._http.get('http://api.openweathermap.org/data/2.5/weather?q=dallas&APPID=3a7e4c95c0333ec8406259e91cb89bc4')
  }
  getChicago(){
    return this._http.get('http://api.openweathermap.org/data/2.5/weather?q=chicago&APPID=3a7e4c95c0333ec8406259e91cb89bc4')
  }
}
