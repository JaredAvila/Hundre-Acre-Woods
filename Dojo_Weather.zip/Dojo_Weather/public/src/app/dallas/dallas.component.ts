import { Component, OnInit } from '@angular/core';
import { HttpService } from '../http.service';

@Component({
  selector: 'app-dallas',
  templateUrl: './dallas.component.html',
  styleUrls: ['./dallas.component.css']
})
export class DallasComponent implements OnInit {

  constructor(private _httpService : HttpService) { }
  weatherHigh = "";
  weatherLow = "";
  weatherAvg = "";
  status = "";
  humidity: '';
  ngOnInit() {
    this.getDallas();
  }
  getDallas() {
    let obs = this._httpService.getDallas();
    obs.subscribe(data=> {
      var tempLowNum = parseInt(data.main.temp_min);
      tempLowNum = (tempLowNum - 273) * 9/5 + 32;
      var tempLow = tempLowNum.toString();
      var tempHighNum = parseInt(data.main.temp_max);
      tempHighNum = (tempHighNum - 273) * 9/5 + 32;
      var tempHigh = tempHighNum.toString();
      var tempNum = parseInt(data.main.temp);
      tempNum = (tempNum - 273) * 9/5 + 32;
      var temp = tempNum.toString();
      this.humidity = data.main.humidity;
      this.weatherLow = ((tempLow) );
      this.weatherHigh = tempHigh;
      this.weatherAvg = temp;
      this.status = data.weather[0].main;
    })
  }
}
