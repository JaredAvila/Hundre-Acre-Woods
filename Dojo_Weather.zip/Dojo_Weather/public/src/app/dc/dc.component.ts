import { Component, OnInit } from '@angular/core';
import { HttpService } from '../http.service';

@Component({
  selector: 'app-dc',
  templateUrl: './dc.component.html',
  styleUrls: ['./dc.component.css']
})
export class DcComponent implements OnInit {

  constructor(private _httpService : HttpService) { }
  weatherHigh = "";
  weatherLow = "";
  weatherAvg = "";
  status = "";
  humidity: '';
  ngOnInit() {
    this.getDc();
  }
  getDc() {
    let obs = this._httpService.getDc();
    obs.subscribe(data=> {
      var tempLowNum = parseInt(data.main.temp_min);
      tempLowNum = (tempLowNum - 273) * 9/5 + 32;
      var tempLow = tempLowNum.toString();
      var tempHighNum = parseInt(data.main.temp_max);
      tempHighNum = (tempHighNum - 273) * 9/5 + 32;
      var tempHigh = tempHighNum.toString();
      var tempNum = parseInt(data.main.temp);
      tempNum = (tempNum - 273) * 9/5 + 32;
      var temp = tempNum.toString();
      this.humidity = data.main.humidity;
      this.weatherLow = ((tempLow) );
      this.weatherHigh = tempHigh;
      this.weatherAvg = temp;
      this.status = data.weather[0].main;
    })
  }
}
