const mongoose = require('mongoose');
Message = mongoose.model('Message');
module.exports = {
    getAll: function (req, res) {
        Message.find({}, null, {sort: {createdAt: -1}}, function (err, messages) {
            if (err) {
                res.json({ error: err });
            } else {
                res.json({ messages: messages });
            }
        })
    },
    newMessage: function (req, res) {
        var message = new Message({ message: req.body.message });
        message.save(function (err) {
            if (err) {
                res.json({ error: err });
            } else {
                res.json({ message: message });
            }
        })

    }
}