var mongoose = require('mongoose');
module.exports = mongoose.connect('mongodb://localhost/anonamessage', {useNewUrlParser: true});
