const messages = require('../controllers/messages.js');
module.exports = function(app){
    app.get('/', function(req, res){
        res.json({message: "Heeeeeyyya!"})
    })
    app.get('/api/messages', function(req, res){
        messages.getAll(req, res);
    })
    app.post('/api/message/new', function(req, res){
        messages.newMessage(req, res);
    })
}