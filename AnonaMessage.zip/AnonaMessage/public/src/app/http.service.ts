import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class HttpService {

  constructor(private _http: HttpClient) { }
  msgs = [];
  newMessage(message){
    return this._http.post("/api/message/new", message);
  }
  getAll(){
    return this._http.get("/api/messages");
  }

}
