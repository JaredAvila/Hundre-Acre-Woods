import { Component, OnInit } from '@angular/core';
import { HttpService } from './http.service';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit{
  constructor(private _httpService: HttpService){}
  newMsg = {message: ""};
  messages = [];
  ngOnInit(){this.getMessages();}
  getMessages(){
    let obs = this._httpService.getAll();
    obs.subscribe(data => {
      console.log(data);
      this.messages = data['messages'];
    });
  }
  newMessage(){
    let obs = this._httpService.newMessage(this.newMsg);
    obs.subscribe(data => {
      console.log("Heres the new message! ", data);
    })
    this.newMsg = {message: ""};
    this.getMessages();
  }
}
