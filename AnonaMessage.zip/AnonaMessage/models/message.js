var mongoose = require('mongoose');
require('../config/mongoose.js');
module.exports = {
    message: function(){
        var MessageSchema = new mongoose.Schema({
            message: {type:String, required: true, minlength: [3, "Message must be at least 3 characters long."]}
        }, { timestamps: true });
        mongoose.model('Message', MessageSchema);
    }
}