var express = require('express');
var app = express();
var mongoose = require('mongoose');
var bodyParser = require('body-parser');
app.use(bodyParser.urlencoded({ extended: true }));
var path = require('path');
const flash = require('express-flash');
var session = require('express-session');
app.use(session({
    secret: 'superSercretCode!',
    resave: false,
    saveUninitialized: true,
    cookie: { maxAge: 60000 }
}));
app.use(flash());
app.use(express.static(path.join(__dirname, './static')));
app.set('views', path.join(__dirname, './views'));
app.set('view engine', 'ejs');
//----------------------------------------------------------------------- Routes
//-------------------------------------------------------------------- Root Request

app.get('/home', function (req, res) {
    Message.find({}, function(err, messages){
        if(err){
            // console.log("Error message: " + err);
        }
        res.render("home", {msgs: messages});
    })
})

app.post('/message', function (req, res) {
    var message = new Message(req.body);
    message.save(function(err) {
        if (err) {
            for (var key in err.errors) {
                req.flash('mesErr', err.errors[key].message);
            }
            console.log("and we're off");
            res.redirect('/home');
        }
    })
})

app.post('/message/:id/comment', function(req, res){
    var comment = new Comment(req.body);
    comment.save(function(err) {
        if (err) {
            for (var key in err.errors) {
                console.log(err.errors[key].message);
                req.flash('comErr', err.errors[key].message);
            }
        } else{
            Message.findById(req.params.id, function(err, message){
                message.comments.push(comment);
                message.save();
            })
        }
        res.redirect('/home');
    });
})

//-------------------------------------------------------------------connections - n - stuffs

app.listen(8000, function () {
    console.log("listening on port 8000");
})

mongoose.connect('mongodb://localhost/msgBoard', { useNewUrlParser: true });
const CommentSchema = new mongoose.Schema({
    name: { type: String, required: [true, "Name can't be left blank"] },
    comment: { type: String, required: [true, "Comments can't be left blank"] }
}, { timestamps: true });
const MessageSchema = new mongoose.Schema({
    name: { type: String, required: [true, "Name can't be left blank"] },
    message: { type: String, required: [true, "Message can't be left blank"] },
    comments: [CommentSchema]
}, { timestamps: true });
mongoose.model('Comment', CommentSchema);
mongoose.model('Message', MessageSchema);
mongoose.Promise = global.Promise;
var Comment = mongoose.model('Comment');
var Message = mongoose.model('Message');