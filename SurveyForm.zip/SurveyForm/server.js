var express = require("express");
var path = require("path");
var app = express();
var bodyParser = require('body-parser');
var session = require('express-session');
app.use(session({
    secret: 'superSercretCode!',
    resave: false,
    saveUninitialized: true,
    cookie: { maxAge: 60000 }
}))
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, "./static")));
app.set('views', path.join(__dirname, './views'));
app.set('view engine', 'ejs');
app.get('/', function (req, res) {
    res.render("index");
})
app.post('/', function (req, res) {
    var name = req.body.name;
    var location = req.body.location;
    var language = req.body.language;
    var comment = req.body.comment;
    var result = {"name": name, "location": location, "language": language, "comment": comment};
    req.session.result = result;
    res.redirect("/success");
})
app.get('/success', function (req, res) {
    var result = req.session.result;
    res.render("result", {result: result});
})
app.listen(8000, function () {
    console.log("listening on port 8000");
});