import { Component, OnInit } from '@angular/core';
import { ShintoService } from '../shinto.service';

@Component({
  selector: 'app-sell',
  templateUrl: './sell.component.html',
  styleUrls: ['./sell.component.css']
})
export class SellComponent implements OnInit {
  value = this._shintoService.coinValue;
  numberToSell = "";
  totalCocs = this._shintoService.totalCoins;
  error = "";
  constructor(private _shintoService: ShintoService) { }
  ledger = this._shintoService.ledger;

  ngOnInit() {
  }
  sellCoins(){
    console.log("bout it!");
    console.log(this.numberToSell);
    if(this.totalCocs < parseInt(this.numberToSell)){
      this.error = "You don't have enough coins. Go mine or buy some more!";
    } else if (this.totalCocs >= parseInt(this.numberToSell)){
      this._shintoService.totalCoins = this._shintoService.totalCoins -= parseInt(this.numberToSell);
      this.error = "";
      this.totalCocs = this._shintoService.totalCoins;
      let entry = {amount: this.numberToSell, value: this._shintoService.coinValue, action: "Sold", id: this._shintoService.id};
      this.ledger.push(entry);
      this._shintoService.ledger = this.ledger;
      this._shintoService.id += 1;
      this.numberToSell = "";
    } else {
      this.error = "Must enter a number";
      this.numberToSell = "";
    }
    
  }

}
