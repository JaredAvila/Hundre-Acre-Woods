import { Component, OnInit } from '@angular/core';
import { ShintoService } from './shinto.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  constructor(private _shintoService: ShintoService) { }
  cocCoins: any;
  newCoin={total: "0", currentValue: "1"};;
  ngOnInit() {
  }
  // getCoins() {
  //   console.log("we are in getCoins");
  //   let obs = this._shintoService.getCoins(this.newCoin);
  //   obs.subscribe(data => {
  //     console.log("data: ", data);
  //     if (data['errors']) {
  //       this.cocCoins = "";
  //     } else {
  //       this.cocCoins = data;
  //     }
  //   })
  // }
}
