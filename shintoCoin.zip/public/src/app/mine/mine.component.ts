import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { ShintoService } from '../shinto.service';

@Component({
  selector: 'app-mine',
  templateUrl: './mine.component.html',
  styleUrls: ['./mine.component.css']
})
export class MineComponent implements OnInit {
  trivia : any;
  question = "tq";
  answer = "ta";
  myAnswer = "";
  message = "";
  totalCoins = this._shintoService.totalCoins;
  ledger = this._shintoService.ledger;
  constructor(private _http: HttpClient, private _shintoService: ShintoService) { }

  ngOnInit() {
    this.getTrivia();
  }
  getTrivia(){
    let observable = this._http.get('https://opentdb.com/api.php?amount=1&difficulty=easy&type=boolean');
    observable.subscribe(data => {
      this.trivia = data;
      this.answer = this.trivia.results[0].correct_answer;
      this.question = this.trivia.results[0].question;
    })
  }
  checkAnswer(){
    if (this.myAnswer === this.answer) {
      this.message = "Correct! 1 coin has been added. Congrats!"
      this._shintoService.totalCoins += 1;
      this.totalCoins = this._shintoService.totalCoins;
      this.myAnswer = "";
      let entry = {amount: 1, value: this._shintoService.coinValue, action: "Mined", id: this._shintoService.id};
      this.ledger.push(entry);
      this._shintoService.ledger = this.ledger;
      this._shintoService.id += 1;
      this.getTrivia();
    } else {
      this.message = "No coin for you! Try again"
      this.myAnswer = "";
      this.getTrivia();
    }
  }

}
