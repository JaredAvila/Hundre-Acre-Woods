import { Component, OnInit } from '@angular/core';
import { ShintoService } from '../shinto.service';

@Component({
  selector: 'app-buy',
  templateUrl: './buy.component.html',
  styleUrls: ['./buy.component.css']
})
export class BuyComponent implements OnInit {
  constructor(private _ShintoService : ShintoService) { }
  coinValue = this._ShintoService.coinValue;
  totalCoins = this._ShintoService.totalCoins;
  ledger = this._ShintoService.ledger;
  numberToBuy = "";
  error = "";
  
  
  ngOnInit() {
  }
  buyCoins(){
    if(Number.isInteger(parseInt(this.numberToBuy)) === true){
      this._ShintoService.totalCoins = this._ShintoService.totalCoins += parseInt(this.numberToBuy);
      this.error = "";
      this.totalCoins = this._ShintoService.totalCoins;
      let idLink = "['/details/"+ this._ShintoService.id +"']";
      let entry = {amount: this.numberToBuy, idLink: idLink, value: this._ShintoService.coinValue, action: "Purchased", id: this._ShintoService.id};
      this.ledger.push(entry);
      this._ShintoService.ledger = this.ledger;
      this.numberToBuy = "";
      this._ShintoService.id += 1;
    } else{
      this.error = "Must enter a number";
    }
    
  }
}
