import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http'
@Injectable({
  providedIn: 'root'
})
export class ShintoService {

  constructor(private _http: HttpClient) {
  }
  totalCoins = 0;
  coinValue = 5;
  ledger = [];
  id = 1;
  getCoins(newCoin) {
    console.log("shintoService getCoins now...");
    return this._http.post('/coins', newCoin);
  }
}

